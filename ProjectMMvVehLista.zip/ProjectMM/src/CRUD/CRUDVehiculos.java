/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CRUD;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
public class CRUDVehiculos {  
    private final Connection conexion;

    public CRUDVehiculos(Connection conexion) {
        this.conexion = conexion;
    }
    public String[] buscarVehiculos(String CodVeh) {
        
        String[] datos = new String[3];
        
        try {
            String SQL = "SELECT * FROM vehiculos WHERE CodVeh = ?";
            PreparedStatement consulta = this.conexion.prepareStatement(SQL);
            consulta.setString(1, CodVeh);
            ResultSet resultado = consulta.executeQuery();
            
            while (resultado.next()) {
                datos[0] = resultado.getString("PlacaVeh");
                datos[1] = resultado.getString("AceiteUt");                                                
                datos[2] = resultado.getString("FechaAd"); //REVISAR , obtener la fecha sin que explote
                datos[3] = resultado.getString("MarcaVeh");
                datos[4] = resultado.getString("ModeloVeh");
            }                            
            
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Fallo del Registro" + e.getMessage());
        }
        
        return datos;
    }
    
    public void nuevoVehiculos (String CodVeh, String PlacaVeh, String AceiteUt, String FechaAdq, String MarcaVeh, String ModeloVeh) {
        try {
            String SQL = "INSERT INTO vehiculos (CodVeh, PlacaVeh, AceiteUt, FechaAdq, MarcaVeh, ModeloVeh) VALUES (?,?,?,?,?,?)";
            PreparedStatement consulta = this.conexion.prepareStatement(SQL);

            consulta.setString(1, CodVeh);
            consulta.setString(2, PlacaVeh);
            consulta.setString(3, AceiteUt);
              consulta.setString(4,FechaAdq); //STRING DE MOMENTOS
            consulta.setString(5, MarcaVeh);
            consulta.setString(6, ModeloVeh);
            consulta.execute();
            JOptionPane.showMessageDialog(null, "Vehiculo Registrado");

        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Fallo del Registro" + e.getMessage());
        }
    }
    
    public void actualizarVehiculos(String CodVeh, String PlacaVeh, String AceiteUt, String FechaAdq, String MarcaVeh, String ModeloVeh) {
        
        try {
            String SQL = "UPDATE vehiculos SET PlacaVeh=?, AceiteUt=?, FechaAdq=?,MarcaVeh=?,ModeloVeh=? WHERE CodVeh=?";
            PreparedStatement consulta = this.conexion.prepareStatement(SQL);
            
            consulta.setString(1, PlacaVeh);
            consulta.setString(2, AceiteUt);
            consulta.setString(3,FechaAdq); // STRING DE MOMENTOS
            consulta.setString(4, MarcaVeh);
            consulta.setString(5, ModeloVeh);
            consulta.setString(6, CodVeh);
            
            consulta.execute();
            JOptionPane.showMessageDialog(null, "Registro actualizado exitosamente");

        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Fallo al editar el registro" + e.getMessage());
        }
    }
    
    public void eliminarVehiculo (String CodVeh) {
        
        try {
            String SQL = "DELETE FROM vehiculos WHERE CodVeh=?";
            PreparedStatement consulta = this.conexion.prepareStatement(SQL);
            consulta.setString(1, CodVeh);
            consulta.execute();
            JOptionPane.showMessageDialog(null, "Registro eliminado exitosamente");

        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Fallo al editar el registro" + e.getMessage());
        }
    }
    

}